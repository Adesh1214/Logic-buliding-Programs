#include<iostream>
using namespace std;

int main()
{
    cout<<"Jay Ganesh"<<endl;
    
    return 0;
}